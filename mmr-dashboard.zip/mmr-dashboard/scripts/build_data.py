"""Convert the Problem Management tracker (xlsx) into site/data.json."""
import json, sys, datetime as dt
import pandas as pd
src = sys.argv[1] if len(sys.argv) > 1 else "data/Problem_Management_Tracker.xlsx"
df = pd.read_excel(src)
df.columns = [str(c).strip() for c in df.columns]
need = ["Region","Building Code","Problem Record","Issue Description","Assignee","Created","PR State","SLA Matrix"]
missing = [c for c in need if c not in df.columns]
if missing: sys.exit(f"Missing columns in {src}: {missing}")
df = df[df["Problem Record"].notna()].copy()
for c in ("Created","Closed date"):
    if c in df: df[c] = pd.to_datetime(df[c], errors="coerce").dt.strftime("%Y-%m-%d").fillna("")
df["Created Month"] = df["Created"].str[:7]
df["Closure Status"] = df["PR State"].astype(str).str.strip().map(lambda s: "Resolved" if s == "Resolved" else "Open")
df = df.astype(object).where(df.notna(), None)
recs = json.loads(df.to_json(orient="records"))
out = {"updated": dt.datetime.now(dt.timezone.utc).isoformat(), "records": recs}
json.dump(out, open("site/data.json","w"), ensure_ascii=False)
print(f"{len(recs)} records written to site/data.json")
