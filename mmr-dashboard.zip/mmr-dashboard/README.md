# MMR Operations Dashboard 2026
Static dashboard (`site/index.html`) fed by `site/data.json`, rebuilt from the tracker Excel and redeployed to GitHub Pages every day.

## Setup
1. Create a GitHub repo and push these files to `main`.
2. Settings → Pages → Source: **GitHub Actions**.
3. Choose how the daily data gets in:
   - **A. Direct URL (fully automatic):** add repo secret `TRACKER_URL` = a direct-download link to the xlsx (e.g. a OneDrive/SharePoint/Drive "anyone with link" download URL). Each daily run fetches it.
   - **B. Manual:** overwrite `data/Problem_Management_Tracker.xlsx` and push; the push triggers a deploy. The daily run still re-deploys.
4. Actions → "Build & deploy dashboard" → Run workflow. Live URL: `https://<user>.github.io/<repo>/`.

Schedule: edit the `cron` line in `.github/workflows/deploy.yml` (UTC).

## Expected xlsx columns
Region, Country, City, Building Code, Problem Record, Issue Description, Assignee, Created, Closed date, Days Open, SLA Matrix, PR State, Pending Open Days, Remarks, Response.

## Privacy
GitHub Pages sites are public on free/Team plans. This data contains internal records: use a private repo with GitHub Enterprise Cloud (access-controlled Pages) or your company's GitHub, and get approval first.
